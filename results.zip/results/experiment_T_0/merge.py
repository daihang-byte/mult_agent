import pandas as pd

# 要合并的 CSV 文件
files = [
    "agent_data.csv",
    "decisions.csv",
    "model_data.csv"
]

# 输出的 Excel 文件名
output_excel = "experiment_results.xlsx"

# 创建 ExcelWriter
with pd.ExcelWriter(output_excel) as writer:
    for file in files:
        # 读取 CSV
        df = pd.read_csv(file)

        # 以文件名（去掉.csv）作为 Sheet 名
        sheet_name = file.replace(".csv", "")

        # 写入到对应 Sheet
        df.to_excel(writer, sheet_name=sheet_name, index=False)

print(f"✅ 已生成 {output_excel}，每个 CSV 在不同的 Sheet 中")
