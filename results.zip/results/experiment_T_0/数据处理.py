import pandas as pd
import numpy as np

# ===== 基尼系数计算函数 =====
def gini_coefficient(values):
    """计算基尼系数"""
    values = np.array(values)
    if np.amin(values) < 0:
        values -= np.amin(values)  # 处理负值
    values += 1e-9  # 避免除零
    values = np.sort(values)
    n = len(values)
    index = np.arange(1, n + 1)
    return ((np.sum((2 * index - n - 1) * values)) / (n * np.sum(values)))

# ===== 读取数据 =====
file_path = r"D:\乐云云盘\财富分配模型2.4\results\experiment_T_0\experiment_results.xlsx"
sheet_name = "agent_data"

df = pd.read_excel(file_path, sheet_name=sheet_name)

# ===== 计算每步的利他比例 =====
altruism_ratio_per_step = df.groupby("step")["moral_level"].mean()  # moral_level==1 时比例即为平均值

# ===== 计算全程平均利他比例 =====
avg_altruism_ratio = altruism_ratio_per_step.mean()

# ===== 标记高道德 / 低道德 =====
morality_label = altruism_ratio_per_step.apply(lambda x: "High" if x > avg_altruism_ratio else "Low")

# ===== 每步基尼系数 & 总财富 =====
gini_per_step = df.groupby("step")["wealth"].apply(gini_coefficient)
total_wealth_per_step = df.groupby("step")["wealth"].sum()

# ===== 汇总结果 =====
result_df = pd.DataFrame({
    "Step": altruism_ratio_per_step.index,
    "Altruism_Ratio": altruism_ratio_per_step.values,
    "Morality_Level": morality_label.values,
    "Gini": gini_per_step.values,
    "Total_Wealth": total_wealth_per_step.values
})

# ===== 保存到 Excel 方便后续分析 =====
output_path = r"D:\乐云云盘\财富分配模型2.4\results\experiment_T_0\morality_analysis.xlsx"
result_df.to_excel(output_path, index=False)

print("处理完成！结果已保存到：", output_path)
